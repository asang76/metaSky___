import React from 'react'
import {
    MDBCarousel,
    MDBCarouselItem,
    MDBCol,
    MDBTypography,
    MDBContainer,
    MDBRow,
  } from "mdb-react-ui-kit";
  import './testimonial.css'
  import userimg from '../asset/svg/testimonialsvg/userimg.svg'
import TestimonialUser from './TestimonialUser';

const Testimonial = () => {
  return (
    <div className='testimonial_container'>

    <MDBContainer className="py-5">
    <MDBCarousel showControls dark>
        <MDBCarouselItem className="active">
          <MDBContainer>
            <MDBRow className="text-center">
              <MDBCol lg="4" className="mb-5 mb-md-0">
              <div className="d-flex justify-content-center mb-4">
                  <img
                    src={userimg}
                    className=" w-25 shadow-1-strong"
                    alt=''
                    />
                </div>
                <h5 className="mb-3">hlrlo</h5>
                <h6 className="text-primary mb-3">heelo</h6>
                <MDBTypography
                  listUnStyled
                  className="d-flex justify-content-center mb-0"
                  >
                </MDBTypography>
              </MDBCol>
              <MDBCol lg="4" className="d-none d-lg-block">
               <TestimonialUser/>
              </MDBCol>
              <MDBCol lg="4" className="d-none d-lg-block">
               <TestimonialUser/>
              </MDBCol>
            </MDBRow>
          </MDBContainer>
        </MDBCarouselItem>
        <MDBCarouselItem>
          <MDBContainer>
            <MDBRow className="text-center">
              <MDBCol lg="4" className="mb-5 mb-md-0">
                <TestimonialUser/>
              </MDBCol>
              <MDBCol lg="4" className="d-none d-lg-block">
                <TestimonialUser/>
              </MDBCol>
            </MDBRow>
          </MDBContainer>
        </MDBCarouselItem>
        <MDBCarouselItem>
          <MDBContainer>
            <MDBRow className="text-center">
              <MDBCol lg="4" className="mb-5 mb-md-0">
               <TestimonialUser/>

              </MDBCol>
              <MDBCol lg="4" className="d-none d-lg-block">
                <TestimonialUser/>
               
              </MDBCol>
              <MDBCol lg="4" className="d-none d-lg-block">
               <TestimonialUser/>    
              </MDBCol>
            </MDBRow>
          </MDBContainer>
        </MDBCarouselItem>
      
    </MDBCarousel>
  </MDBContainer>

    </div>
  )
}

export default Testimonial
