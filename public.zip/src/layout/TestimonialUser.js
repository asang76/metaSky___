import React from 'react'

const TestimonialUser = ({img,name,job}) => {
  return (
    <>
      <div className="d-flex justify-content-center mb-4">
                  <img
                    src={img}
                    className=" w-25 shadow-1-strong"
                    
                    alt=''
                    />
                </div>
                <h5 className="mb-3">{name}</h5>
                <h6 className="text-primary mb-3">{job}</h6>  
                    </>
    
  )
}

export default TestimonialUser
